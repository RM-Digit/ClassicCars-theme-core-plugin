"use strict"

jQuery(document).ready(function () {
    jQuery('body').addClass('vehica-elementor-editor');
});